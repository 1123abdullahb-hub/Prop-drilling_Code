import { useContext } from "react";
import { ThemeContext } from "./context/ThemeContext";
import ThemeButton from "./components/ThemeButton";

function App() {
  const { theme } = useContext(ThemeContext);

  const style = {
    backgroundColor: theme === "light" ? "white" : "black",
    color: theme === "light" ? "black" : "white",
    minHeight: "100vh",
    padding: "30px",
  };

  return (
    <div style={style}>
      <h1>Theme Context App</h1>
      <p>This is a reusable theme application.</p>
      <ThemeButton />
    </div>
  );
}

export default App;